/// App-wide constants. Change money rules here (and mirror them in supabase/schema.sql).
class AppConfig {
  static const appName = 'Mverechena';
  static const ecocashNumber = '0776689132';
  static const activationFee = 1.0;
  static const minBid = 2.0;
  static const feeRate = 0.10; // platform keeps 10% of the accepted bid ...
  static const minFee = 1.0; // ... or $1 if 10% is less than a dollar
  static const usernameDomain = 'mverechena.app'; // hidden e-mail suffix for username login
  static const maxKeywordAttempts = 5;

  static double feeFor(double amount) {
    final f = double.parse((amount * feeRate).toStringAsFixed(2));
    return f < minFee ? minFee : f;
  }

  static double payoutFor(double amount) =>
      double.parse((amount - feeFor(amount)).toStringAsFixed(2));
}
