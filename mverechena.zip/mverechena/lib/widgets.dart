import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'logo.dart';
import 'models.dart';
import 'services.dart';
import 'theme.dart';

class VenusButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool loading;
  final IconData? icon;
  const VenusButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.loading = false,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null && !loading;
    return Opacity(
      opacity: enabled ? 1 : 0.6,
      child: InkWell(
        borderRadius: BorderRadius.circular(28),
        onTap: enabled ? onPressed : null,
        child: Ink(
          decoration: BoxDecoration(
            gradient: Venus.gradient,
            borderRadius: BorderRadius.circular(28),
          ),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 22),
            alignment: Alignment.center,
            child: loading
                ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white),
                  )
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (icon != null) ...[
                        Icon(icon, color: Colors.white, size: 20),
                        const SizedBox(width: 8),
                      ],
                      Flexible(
                        child: Text(
                          label,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}

class Splash extends StatelessWidget {
  final String? label;
  const Splash({super.key, this.label});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: Venus.bgGradient),
        alignment: Alignment.center,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const BrandHeader(logoSize: 120),
            const SizedBox(height: 28),
            const CircularProgressIndicator(color: Venus.rose),
            if (label != null) ...[
              const SizedBox(height: 16),
              Text(label!, style: const TextStyle(color: Venus.pearl)),
            ],
          ],
        ),
      ),
    );
  }
}

class StatusChip extends StatelessWidget {
  final String text;
  final Color color;
  const StatusChip(this.text, this.color, {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.5)),
      ),
      child: Text(text,
          style: TextStyle(
              color: color, fontSize: 12, fontWeight: FontWeight.w700)),
    );
  }
}

class CopyRow extends StatelessWidget {
  final String label;
  final String value;
  const CopyRow(this.label, this.value, {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.only(left: 14),
      decoration: BoxDecoration(
        color: Venus.blush.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(fontSize: 11, color: Venus.copper)),
                Text(value,
                    style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: Venus.wine)),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.copy, color: Venus.wine),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: value));
              toast('Copied');
            },
          ),
        ],
      ),
    );
  }
}

/// Subscribes to a realtime stream once (not on every rebuild) and rebuilds on each change.
class Live extends StatefulWidget {
  final Stream<Rows> Function() create;
  final Widget Function(BuildContext, AsyncSnapshot<Rows>) builder;
  const Live({super.key, required this.create, required this.builder});

  @override
  State<Live> createState() => _LiveState();
}

class _LiveState extends State<Live> {
  late final Stream<Rows> _stream = widget.create();

  @override
  Widget build(BuildContext context) =>
      StreamBuilder<Rows>(stream: _stream, builder: widget.builder);
}

Stream<Rows> notificationsStream(String uid) => sb
    .from('notifications')
    .stream(primaryKey: ['id'])
    .eq('user_id', uid)
    .order('created_at', ascending: false)
    .limit(60);

/// Bell with an unread badge; opens the notification inbox.
class NotificationsButton extends StatelessWidget {
  final String uid;
  final Color? color;
  const NotificationsButton({super.key, required this.uid, this.color});

  @override
  Widget build(BuildContext context) {
    return Live(
      create: () => notificationsStream(uid),
      builder: (context, snap) {
        final n = (snap.data ?? []).where((r) => r['read'] == false).length;
        return IconButton(
          color: color,
          icon: Badge(
            isLabelVisible: n > 0,
            label: Text('$n'),
            child: const Icon(Icons.notifications_outlined),
          ),
          onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => NotificationsScreen(uid: uid))),
        );
      },
    );
  }
}

class NotificationsScreen extends StatefulWidget {
  final String uid;
  const NotificationsScreen({super.key, required this.uid});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  @override
  void initState() {
    super.initState();
    _markRead();
  }

  Future<void> _markRead() async {
    try {
      await sb
          .from('notifications')
          .update({'read': true})
          .eq('user_id', widget.uid)
          .eq('read', false);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Notifications')),
      body: Live(
        create: () => notificationsStream(widget.uid),
        builder: (context, snap) {
          if (snap.hasError) return Center(child: Text(errText(snap.error!)));
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = snap.data!;
          if (docs.isEmpty) {
            return const Center(child: Text('Nothing here yet.'));
          }
          return ListView.separated(
            itemCount: docs.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (_, i) {
              final d = docs[i];
              return ListTile(
                leading: const Icon(Icons.favorite, color: Venus.rose),
                title: Text('${d['title'] ?? ''}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text('${d['body'] ?? ''}'),
                trailing: Text(fmtTs(d['created_at']),
                    style: const TextStyle(fontSize: 11)),
              );
            },
          );
        },
      ),
    );
  }
}

Future<void> signOut() => sb.auth.signOut();
