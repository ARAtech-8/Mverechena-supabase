import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'models.dart';
import 'screens/activation_screen.dart';
import 'screens/admin_screen.dart';
import 'screens/auth_screen.dart';
import 'screens/home_shell.dart';
import 'services.dart';
import 'supabase_config.dart';
import 'theme.dart';
import 'widgets.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: SupabaseConfig.url,
    anonKey: SupabaseConfig.anonKey,
  );
  runApp(const MverechenaApp());
}

class MverechenaApp extends StatelessWidget {
  const MverechenaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mverechena',
      debugShowCheckedModeBanner: false,
      theme: Venus.theme,
      scaffoldMessengerKey: messengerKey,
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: sb.auth.onAuthStateChange,
      builder: (context, snap) {
        final session = snap.hasData ? snap.data!.session : sb.auth.currentSession;
        final user = session?.user;
        if (user == null) return const AuthScreen();
        return UserGate(key: ValueKey(user.id), uid: user.id);
      },
    );
  }
}

/// Routes the signed-in user: not paid yet -> activation, admin -> admin panel,
/// otherwise the male/female app.
class UserGate extends StatefulWidget {
  final String uid;
  const UserGate({super.key, required this.uid});

  @override
  State<UserGate> createState() => _UserGateState();
}

class _UserGateState extends State<UserGate> {
  late final Stream<Rows> _profile =
      sb.from('profiles').stream(primaryKey: ['id']).eq('id', widget.uid);

  StreamSubscription<Rows>? _notifSub;
  final _seen = <dynamic>{};
  bool _firstBatch = true;

  @override
  void initState() {
    super.initState();
    // Pop up a short message when a new notification arrives while the app is open.
    _notifSub = notificationsStream(widget.uid).listen((rows) {
      for (final r in rows) {
        final isNew = _seen.add(r['id']);
        if (isNew && !_firstBatch && r['read'] == false) {
          toast('${r['title'] ?? ''}\n${r['body'] ?? ''}'.trim());
        }
      }
      _firstBatch = false;
    }, onError: (_) {});
  }

  @override
  void dispose() {
    _notifSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final uid = widget.uid;
    return StreamBuilder<Rows>(
      stream: _profile,
      builder: (context, snap) {
        if (snap.hasError) {
          return Scaffold(
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(errText(snap.error!), textAlign: TextAlign.center),
                    TextButton(onPressed: signOut, child: const Text('Sign out')),
                  ],
                ),
              ),
            ),
          );
        }
        final rows = snap.data;
        if (rows == null || rows.isEmpty) {
          return const Splash(label: 'Setting up your account...');
        }
        final me = rows.first;
        if (me['status'] == 'suspended') {
          return Scaffold(
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.block, size: 48, color: Venus.wine),
                    const SizedBox(height: 12),
                    const Text(
                      'This account has been suspended. Contact Mverechena support.',
                      textAlign: TextAlign.center,
                    ),
                    TextButton(onPressed: signOut, child: const Text('Sign out')),
                  ],
                ),
              ),
            ),
          );
        }
        if (me['status'] != 'active') {
          return ActivationScreen(uid: uid, me: me);
        }
        if (me['role'] == 'admin') return AdminScreen(uid: uid, me: me);
        return HomeShell(uid: uid, me: me);
      },
    );
  }
}
