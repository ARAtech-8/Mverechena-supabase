import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'config.dart';

SupabaseClient get sb => Supabase.instance.client;

final messengerKey = GlobalKey<ScaffoldMessengerState>();

void toast(String message) {
  messengerKey.currentState?.hideCurrentSnackBar();
  messengerKey.currentState?.showSnackBar(
    SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
  );
}

String errText(Object e) {
  if (e is String) return e;
  if (e is PostgrestException) return e.message;
  if (e is StorageException) return e.message;
  if (e is AuthException) {
    final m = e.message.toLowerCase();
    if (m.contains('invalid login')) return 'Wrong username or password.';
    if (m.contains('already registered') || m.contains('already been registered')) {
      return 'That username is already taken.';
    }
    if (m.contains('password should be') || m.contains('weak')) {
      return 'Password is too weak (use at least 6 characters).';
    }
    if (m.contains('rate limit') || m.contains('too many')) {
      return 'Too many attempts. Try again in a few minutes.';
    }
    if (m.contains('not confirmed')) {
      return 'Sign-in is blocked: turn off "Confirm email" in Supabase (see README).';
    }
    if (m.contains('database error')) {
      return 'Could not create the account. That username may already be taken.';
    }
    return e.message;
  }
  final s = e.toString();
  if (s.contains('SocketException') ||
      s.contains('ClientException') ||
      s.contains('Failed host lookup')) {
    return 'No internet connection.';
  }
  return s;
}

/// Runs [f], shows a toast on failure. Returns true when it succeeded.
Future<bool> guard(Future<void> Function() f) async {
  try {
    await f();
    return true;
  } catch (e) {
    toast(errText(e));
    return false;
  }
}

String emailFor(String username) =>
    '${username.trim().toLowerCase()}@${AppConfig.usernameDomain}';

/// Calls a database function (see supabase/schema.sql). All money-state changes
/// go through these so the phone can never fake an escrow confirmation,
/// a keyword match or a payout.
class Api {
  static Future<Map<String, dynamic>> call(String fn,
      [Map<String, dynamic>? params]) async {
    try {
      final res = await sb.rpc(fn, params: params ?? {});
      if (res is Map) return Map<String, dynamic>.from(res);
      return {'value': res};
    } on PostgrestException catch (e) {
      throw e.message;
    }
  }
}

Future<void> openUrl(String url) async {
  final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  if (!ok) toast('Could not open that link.');
}

Future<void> callPhone(String phone) => openUrl('tel:$phone');

Future<void> openMaps(String query) => openUrl(
    'https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(query)}');

String bidCode(String id) => '#${id.substring(0, 6).toUpperCase()}';
