import 'package:flutter/material.dart';

/// Venusian palette: rose quartz, copper (Venus's metal), emerald (Venus's green),
/// wine, and pearl.
class Venus {
  static const rose = Color(0xFFE8A0BF);
  static const blush = Color(0xFFF7D6E2);
  static const copper = Color(0xFFB87333);
  static const emerald = Color(0xFF1F8A70);
  static const wine = Color(0xFF4A1030);
  static const plum = Color(0xFF2A0A1C);
  static const pearl = Color(0xFFFFF5F7);

  static const gradient = LinearGradient(
    colors: [copper, Color(0xFFD9748F)],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );

  static const bgGradient = LinearGradient(
    colors: [plum, wine, Color(0xFF7A2A52)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static ThemeData get theme {
    final scheme = ColorScheme.fromSeed(
      seedColor: copper,
      brightness: Brightness.light,
    ).copyWith(
      primary: wine,
      onPrimary: Colors.white,
      secondary: copper,
      tertiary: emerald,
      surface: pearl,
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: pearl,
      appBarTheme: const AppBarTheme(
        backgroundColor: wine,
        foregroundColor: pearl,
        centerTitle: true,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: blush),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: blush),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: copper, width: 2),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: wine,
        indicatorColor: rose.withValues(alpha: 0.35),
        labelTextStyle: const WidgetStatePropertyAll(
          TextStyle(color: pearl, fontSize: 12),
        ),
        iconTheme: const WidgetStatePropertyAll(IconThemeData(color: pearl)),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: wine,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        ),
      ),
    );
  }
}
