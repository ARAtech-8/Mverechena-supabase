import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'theme.dart';

/// The Mverechena mark: Venus and Mars combined into one glyph
/// (a circle with a cross below it and an arrow rising to the upper right).
class VenusMarsLogo extends StatelessWidget {
  final double size;
  const VenusMarsLogo({super.key, this.size = 96});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _LogoPainter()),
    );
  }
}

class _LogoPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final u = s.width * 0.88; // drawing unit, leaves room for glow
    final r = u * 0.2;
    final len = u * 0.36;
    final c = Offset(s.width * 0.40, s.height * 0.42);
    final k = math.sqrt1_2;

    final path = Path()..addOval(Rect.fromCircle(center: c, radius: r));
    // Venus cross, pointing down from the circle.
    final crossTop = c + Offset(0, r);
    final crossBottom = c + Offset(0, r + len);
    final crossBar = c + Offset(0, r + len * 0.58);
    path
      ..moveTo(crossTop.dx, crossTop.dy)
      ..lineTo(crossBottom.dx, crossBottom.dy)
      ..moveTo(crossBar.dx - len * 0.42, crossBar.dy)
      ..lineTo(crossBar.dx + len * 0.42, crossBar.dy);
    // Mars arrow, rising to the upper right.
    final start = c + Offset(r * k, -r * k);
    final tip = c + Offset((r + len * 1.1) * k, -(r + len * 1.1) * k);
    final head = len * 0.42;
    path
      ..moveTo(start.dx, start.dy)
      ..lineTo(tip.dx, tip.dy)
      ..moveTo(tip.dx - head, tip.dy)
      ..lineTo(tip.dx, tip.dy)
      ..lineTo(tip.dx, tip.dy + head);

    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = u * 0.085
      ..color = Venus.rose.withValues(alpha: 0.55)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, u * 0.06);
    canvas.drawPath(path, glow);

    final stroke = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = u * 0.06
      ..shader = const LinearGradient(
        colors: [Color(0xFFE6A15C), Venus.rose],
        begin: Alignment.bottomLeft,
        end: Alignment.topRight,
      ).createShader(Offset.zero & s);
    canvas.drawPath(path, stroke);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class BrandHeader extends StatelessWidget {
  final double logoSize;
  final bool dark;
  const BrandHeader({super.key, this.logoSize = 96, this.dark = true});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        VenusMarsLogo(size: logoSize),
        const SizedBox(height: 6),
        Text(
          'Mverechena',
          style: TextStyle(
            fontSize: logoSize * 0.3,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.5,
            color: dark ? Venus.pearl : Venus.wine,
          ),
        ),
        Text(
          'dating app',
          style: TextStyle(
            fontSize: logoSize * 0.14,
            letterSpacing: 4,
            color: dark ? Venus.rose : Venus.copper,
          ),
        ),
      ],
    );
  }
}
