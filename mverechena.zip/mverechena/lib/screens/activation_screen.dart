import 'package:flutter/material.dart';

import '../config.dart';
import '../logo.dart';
import '../services.dart';
import '../theme.dart';
import '../widgets.dart';

/// Shown until the admin confirms the $1 activation payment.
class ActivationScreen extends StatefulWidget {
  final String uid;
  final Map<String, dynamic> me;
  const ActivationScreen({super.key, required this.uid, required this.me});

  @override
  State<ActivationScreen> createState() => _ActivationScreenState();
}

class _ActivationScreenState extends State<ActivationScreen> {
  final _txn = TextEditingController();
  bool _busy = false;

  Future<void> _submit() async {
    final t = _txn.text.trim();
    if (t.length < 4) {
      toast('Enter the transaction ID from your Ecocash confirmation SMS.');
      return;
    }
    setState(() => _busy = true);
    final ok = await guard(() => Api.call('submit_activation', {'p_txn': t}));
    if (ok) toast('Thanks! We will activate your account shortly.');
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final username = (widget.me['username'] ?? '').toString();
    final submitted = (widget.me['activation_txn'] ?? '').toString().isNotEmpty;
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: Venus.bgGradient),
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const Center(child: BrandHeader(logoSize: 90)),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Venus.pearl,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Welcome, @$username',
                        style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            color: Venus.wine)),
                    const SizedBox(height: 6),
                    const Text('Activate your account with a one-time \$1 payment.'),
                    const SizedBox(height: 14),
                    const Text('1. Send \$1 by Ecocash to:',
                        style: TextStyle(fontWeight: FontWeight.w700)),
                    CopyRow('Ecocash number', AppConfig.ecocashNumber),
                    CopyRow('Use this reference', username.toUpperCase()),
                    const SizedBox(height: 10),
                    const Text('2. Enter the transaction ID from the Ecocash SMS:',
                        style: TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _txn,
                      textCapitalization: TextCapitalization.characters,
                      decoration: const InputDecoration(
                          labelText: 'Ecocash transaction ID'),
                    ),
                    const SizedBox(height: 14),
                    VenusButton(
                      label: submitted ? 'Update payment details' : "I've paid",
                      loading: _busy,
                      onPressed: _submit,
                    ),
                    if (submitted) ...[
                      const SizedBox(height: 14),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Venus.emerald.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.hourglass_top,
                                color: Venus.emerald),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                  'Payment received for checking (${widget.me['activation_txn']}). '
                                  'This screen unlocks automatically once confirmed'
                                  '${widget.me['activation_rejected'] == true ? ' - your last reference was rejected, please re-check it.' : '.'}'),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              TextButton(
                onPressed: signOut,
                child: const Text('Sign out',
                    style: TextStyle(color: Venus.rose)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
