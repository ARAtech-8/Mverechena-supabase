import 'package:flutter/material.dart';

import '../logo.dart';
import '../theme.dart';
import '../widgets.dart';
import 'dashboards.dart';
import 'feed_screen.dart';

/// Bottom tab bar: Touchline (feed) | Dashboard | Profile.
class HomeShell extends StatefulWidget {
  final String uid;
  final Map<String, dynamic> me;
  const HomeShell({super.key, required this.uid, required this.me});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _i = 0;

  bool get isMale => widget.me['sex'] == 'male';

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      FeedScreen(uid: widget.uid, me: widget.me),
      isMale
          ? MaleDashboard(uid: widget.uid, me: widget.me)
          : FemaleDashboard(uid: widget.uid, me: widget.me),
      ProfileScreen(uid: widget.uid, me: widget.me),
    ];
    return Scaffold(
      body: pages[_i],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: (v) => setState(() => _i = v),
        destinations: [
          const NavigationDestination(
              icon: Icon(Icons.play_circle_outline), label: 'Touchline'),
          NavigationDestination(
              icon: const Icon(Icons.dashboard_outlined),
              label: isMale ? 'My bids' : 'My offers'),
          const NavigationDestination(
              icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  final String uid;
  final Map<String, dynamic> me;
  const ProfileScreen({super.key, required this.uid, required this.me});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        actions: [NotificationsButton(uid: uid)],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Center(child: BrandHeader(logoSize: 90, dark: false)),
          const SizedBox(height: 20),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.person, color: Venus.wine),
                  title: Text('@${me['username']}'),
                  subtitle: Text(me['sex'] == 'male' ? 'Male' : 'Female'),
                ),
                ListTile(
                  leading: const Icon(Icons.phone, color: Venus.wine),
                  title: Text('${me['phone']}'),
                  subtitle: const Text(
                      'Only shared with your date after escrow is confirmed'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Stay safe',
                      style: TextStyle(
                          fontWeight: FontWeight.w800, color: Venus.wine)),
                  SizedBox(height: 6),
                  Text(
                      '- Meet in a public place and tell a friend where you are.\n'
                      '- Never pay or send money outside the escrow flow.\n'
                      '- Mverechena is for dating and companionship only. Sexual services '
                      'are not allowed and can lead to a permanent ban.\n'
                      '- Use "Report a problem" on any date and the money stays frozen '
                      'until support reviews it.'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          VenusButton(
              label: 'Sign out', icon: Icons.logout, onPressed: signOut),
        ],
      ),
    );
  }
}
