import 'package:flutter/material.dart';

import '../config.dart';
import '../models.dart';
import '../services.dart';
import '../theme.dart';
import '../widgets.dart';
import 'bid_card.dart';


// ----------------------------------------------------------------- male

class MaleDashboard extends StatelessWidget {
  final String uid;
  final Map<String, dynamic> me;
  const MaleDashboard({super.key, required this.uid, required this.me});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('My bids'),
          actions: [NotificationsButton(uid: uid)],
          bottom: const TabBar(
            labelColor: Venus.pearl,
            unselectedLabelColor: Venus.rose,
            indicatorColor: Venus.copper,
            tabs: [Tab(text: 'Bids'), Tab(text: 'Accepted'), Tab(text: 'Cancelled')],
          ),
        ),
        body: Live(
          create: () => sb
              .from('bids')
              .stream(primaryKey: ['id'])
              .eq('male_id', uid)
              .order('created_at', ascending: false)
              .limit(100),
          builder: (context, snap) {
            if (snap.hasError) return Center(child: Text(errText(snap.error!)));
            if (!snap.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final docs = snap.data!;
            Rows pick(List<String> s) =>
                docs.where((d) => s.contains(d['status'])).toList();
            return TabBarView(
              children: [
                _list(pick(pendingStatuses), 'No open bids.\nSwipe the touchline and tap BID.'),
                _list(pick(acceptedStatuses), 'No accepted bids yet.'),
                _list(pick(closedStatuses), 'Nothing cancelled or declined.'),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _list(Rows docs, String empty) {
    if (docs.isEmpty) {
      return Center(
          child: Text(empty,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Venus.copper)));
    }
    return ListView(
      padding: const EdgeInsets.symmetric(vertical: 8),
      children: [
        for (final d in docs) BidCard(b: d, isMale: true, me: me),
      ],
    );
  }
}

// --------------------------------------------------------------- female

class FemaleDashboard extends StatelessWidget {
  final String uid;
  final Map<String, dynamic> me;
  const FemaleDashboard({super.key, required this.uid, required this.me});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My offers'),
        actions: [NotificationsButton(uid: uid)],
      ),
      body: Live(
        create: () => sb
            .from('bids')
            .stream(primaryKey: ['id'])
            .eq('female_id', uid)
            .order('created_at', ascending: false)
            .limit(100),
        builder: (context, snap) {
          final docs = snap.data ?? [];
          final auto = docs.where((d) => d['status'] == 'auto_rejected').length;
          final visible = docs
              .where((d) => !['auto_rejected', 'cancelled', 'expired'].contains(d['status']))
              .toList();
          // new bids needing a decision first, then everything else
          visible.sort((a, b) {
            int rank(Map<String, dynamic> d) => d['status'] == 'pending' ? 0 : 1;
            return rank(a).compareTo(rank(b));
          });
          return ListView(
            padding: const EdgeInsets.symmetric(vertical: 8),
            children: [
              OfferPrices(uid: uid, me: me),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                child: Text('Bids for you',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.w800, color: Venus.wine)),
              ),
              if (auto > 0)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    '$auto bid${auto == 1 ? ' was' : 's were'} below your minimum and declined automatically.',
                    style: const TextStyle(fontSize: 12, color: Venus.copper),
                  ),
                ),
              if (snap.hasError)
                Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(errText(snap.error!)))
              else if (!snap.hasData)
                const Padding(
                    padding: EdgeInsets.all(24),
                    child: Center(child: CircularProgressIndicator()))
              else if (visible.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(
                    child: Text('No bids yet.\nUpload to the touchline to get noticed!',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Venus.copper)),
                  ),
                )
              else
                for (final d in visible) BidCard(b: d, isMale: false, me: me),
            ],
          );
        },
      ),
    );
  }
}

/// The minimum amount she will accept. Bids below it are auto-declined by the server.
class OfferPrices extends StatefulWidget {
  final String uid;
  final Map<String, dynamic> me;
  const OfferPrices({super.key, required this.uid, required this.me});

  @override
  State<OfferPrices> createState() => _OfferPricesState();
}

class _OfferPricesState extends State<OfferPrices> {
  late final _short = TextEditingController(text: _fmt(widget.me['short_min']));
  late final _full = TextEditingController(text: _fmt(widget.me['full_min']));
  bool _busy = false;

  static String _fmt(dynamic v) => v is num ? v.toStringAsFixed(2) : '';

  Future<void> _save() async {
    double? parse(String s) => s.trim().isEmpty ? null : double.tryParse(s.trim());
    final s = parse(_short.text);
    final f = parse(_full.text);
    for (final v in [s, f]) {
      if (v != null && v < AppConfig.minBid) {
        toast('Minimum price must be at least ${money(AppConfig.minBid)}.');
        return;
      }
    }
    setState(() => _busy = true);
    final ok = await guard(() async {
      await sb
          .from('profiles')
          .update({'short_min': s, 'full_min': f}).eq('id', widget.uid);
    });
    if (ok) toast('Offer prices saved. Lower bids are now declined automatically.');
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('My minimum prices',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: Venus.wine)),
            const SizedBox(height: 4),
            const Text(
              'Bids below these are declined automatically. Bids at or above '
              'appear for you to accept or reject. Leave empty to review every bid.',
              style: TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _short,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                        labelText: 'Short time', prefixText: '\$ ', isDense: true),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _full,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                        labelText: 'Full time', prefixText: '\$ ', isDense: true),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: VenusButton(label: 'Save prices', loading: _busy, onPressed: _save),
            ),
            const SizedBox(height: 6),
            const Text(
              'Platform fee: 10% of an accepted bid, or \$1 if 10% is less than \$1.',
              style: TextStyle(fontSize: 11, color: Venus.copper),
            ),
          ],
        ),
      ),
    );
  }
}
