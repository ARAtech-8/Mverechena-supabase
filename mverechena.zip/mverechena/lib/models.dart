import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'theme.dart';

typedef Json = Map<String, dynamic>;
typedef Rows = List<Map<String, dynamic>>;

String money(num v) => '\$${v.toStringAsFixed(2)}';

double numOf(dynamic v) => v is num ? v.toDouble() : double.tryParse('$v') ?? 0;

DateTime? toDate(dynamic v) {
  if (v is DateTime) return v.toLocal();
  if (v is String) return DateTime.tryParse(v)?.toLocal();
  return null;
}

String fmtTs(dynamic v, [String pattern = 'd MMM, HH:mm']) {
  final d = toDate(v);
  return d == null ? '' : DateFormat(pattern).format(d);
}

String typeLabel(String t) => t == 'short' ? 'Short time' : 'Full time';

const pendingStatuses = ['pending'];
const acceptedStatuses = [
  'accepted',
  'escrow_submitted',
  'escrow_confirmed',
  'details_shared',
  'completed',
  'paid',
  'disputed',
];
const closedStatuses = [
  'rejected',
  'auto_rejected',
  'cancelled',
  'expired',
  'refunded',
];

/// Label + colour of the status chip, written from the viewer's point of view.
(String, Color) statusInfo(String status, {required bool isMale}) {
  switch (status) {
    case 'pending':
      return (isMale ? 'Waiting for her' : 'New bid', Venus.copper);
    case 'auto_rejected':
      return ('Too low - declined', Colors.grey);
    case 'rejected':
      return ('Declined', Colors.grey);
    case 'cancelled':
      return ('Cancelled', Colors.grey);
    case 'expired':
      return ('Expired', Colors.grey);
    case 'accepted':
      return (isMale ? 'Accepted - pay escrow' : 'Waiting for confirmation',
          Venus.emerald);
    case 'escrow_submitted':
      return (isMale ? 'Payment under review' : 'Waiting for confirmation',
          Venus.copper);
    case 'escrow_confirmed':
      return (isMale ? 'Escrow secured' : 'Confirmed', Venus.emerald);
    case 'details_shared':
      return (isMale ? 'Date details ready' : 'Date arranged', Venus.emerald);
    case 'completed':
      return (isMale ? 'Meet confirmed' : 'Payout on its way', Venus.emerald);
    case 'paid':
      return (isMale ? 'Completed' : 'Paid', Venus.emerald);
    case 'disputed':
      return ('Under review', Colors.redAccent);
    case 'refunded':
      return ('Refunded', Colors.grey);
    default:
      return (status, Colors.grey);
  }
}
