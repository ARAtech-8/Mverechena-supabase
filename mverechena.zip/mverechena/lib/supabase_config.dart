/// Supabase project: kvvcmfxbvykzqohnetoe.
/// These two values are public identifiers (they ship inside every app), not secrets.
/// Never put the service_role / secret key in the app.
class SupabaseConfig {
  static const url = 'https://kvvcmfxbvykzqohnetoe.supabase.co';
  static const anonKey = 'sb_publishable_honWSAG8CmLHGr0-I1rUdA_UOZ0mpPX';
}
