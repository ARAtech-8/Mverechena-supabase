-- =====================================================================
-- Mverechena backend for Supabase.
-- Paste this whole file into Supabase -> SQL Editor -> New query -> Run.
-- It is safe to run again if something fails half way.
-- =====================================================================

-- ------------------------------------------------------------- tables

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (username ~ '^[a-z0-9_]{3,20}$'),
  phone text not null,
  sex text not null check (sex in ('male', 'female')),
  role text not null default 'user' check (role in ('user', 'admin')),
  status text not null default 'pending' check (status in ('pending', 'active', 'suspended')),
  short_min numeric(10,2) check (short_min is null or short_min >= 2),
  full_min numeric(10,2) check (full_min is null or full_min >= 2),
  bio text,
  activation_txn text,
  activation_rejected boolean,
  activation_submitted_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  owner_name text not null default '',
  media_url text not null,
  storage_path text,
  type text not null check (type in ('image', 'video')),
  caption text not null default '',
  approved boolean not null default false,
  like_count int not null default 0,
  bid_count int not null default 0,
  created_at timestamptz not null default now()
);
create index if not exists posts_new_idx on public.posts (approved, created_at desc);
create index if not exists posts_hot_idx on public.posts (approved, bid_count desc);

create table if not exists public.post_likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists public.bids (
  id uuid primary key default gen_random_uuid(),
  post_id uuid references public.posts(id) on delete set null,
  female_id uuid not null references public.profiles(id),
  female_name text not null,
  male_id uuid not null references public.profiles(id),
  male_name text not null,
  type text not null check (type in ('short', 'full')),
  amount numeric(10,2) not null,
  fee numeric(10,2) not null,
  payout numeric(10,2) not null,
  status text not null default 'pending' check (status in (
    'pending', 'auto_rejected', 'rejected', 'cancelled', 'expired',
    'accepted', 'escrow_submitted', 'escrow_confirmed', 'details_shared',
    'completed', 'paid', 'disputed', 'refunded')),
  keyword_attempts int not null default 0,
  escrow_deadline timestamptz,
  escrow_txn text,
  escrow_rejected boolean,
  payout_txn text,
  created_at timestamptz not null default now(),
  accepted_at timestamptz,
  escrow_submitted_at timestamptz,
  escrow_confirmed_at timestamptz,
  details_at timestamptz,
  completed_at timestamptz,
  paid_at timestamptz
);
create index if not exists bids_male_idx on public.bids (male_id, created_at desc);
create index if not exists bids_female_idx on public.bids (female_id, created_at desc);
create index if not exists bids_status_idx on public.bids (status, created_at desc);

-- Phones and dispute notes: admin only (the two sides never see each other's number early).
create table if not exists public.bid_admin (
  bid_id uuid primary key references public.bids(id) on delete cascade,
  male_phone text,
  female_phone text,
  disputed_by text,
  dispute_reason text,
  prev_status text,
  disputed_at timestamptz
);

-- The keyword: only she (and admin) can read it. He must hear it from her.
create table if not exists public.bid_private (
  bid_id uuid primary key references public.bids(id) on delete cascade,
  female_id uuid not null,
  keyword text not null
);

-- Her time / place / phone. He can read it only after she has shared it.
create table if not exists public.bid_details (
  bid_id uuid primary key references public.bids(id) on delete cascade,
  date_time timestamptz not null,
  location text not null,
  phone text not null
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text not null default '',
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_idx on public.notifications (user_id, created_at desc);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  post_id uuid references public.posts(id) on delete set null,
  owner_id uuid,
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  reason text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.app_settings (
  key text primary key,
  value text
);
insert into public.app_settings (key, value) values ('ntfy_topic', '') on conflict do nothing;

-- ------------------------------------------------------ small helpers

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles
                 where id = auth.uid() and role = 'admin' and status = 'active');
$$;

create or replace function public.is_active() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles
                 where id = auth.uid() and status = 'active');
$$;

create or replace function public.my_sex() returns text
language sql stable security definer set search_path = public as $$
  select sex from public.profiles where id = auth.uid();
$$;

create or replace function public._money(n numeric) returns text
language sql immutable as $$ select '$' || to_char(n, 'FM9999990.00'); $$;

create or replace function public._code(p_id uuid) returns text
language sql immutable as $$ select '#' || upper(left(p_id::text, 6)); $$;

-- 10% of the bid, or $1 if 10% is less than a dollar.
create or replace function public._fee_for(p_amount numeric) returns numeric
language sql immutable as $$ select greatest(round(p_amount * 0.10, 2), 1.00); $$;

create or replace function public._me() returns public.profiles
language plpgsql security definer set search_path = public as $$
declare r public.profiles;
begin
  if auth.uid() is null then raise exception 'Please sign in.'; end if;
  select * into r from public.profiles where id = auth.uid();
  if not found then raise exception 'Account not found.'; end if;
  if r.status <> 'active' then raise exception 'Your account is not active yet.'; end if;
  return r;
end $$;

create or replace function public._admin() returns public.profiles
language plpgsql security definer set search_path = public as $$
declare r public.profiles;
begin
  r := public._me();
  if r.role <> 'admin' then raise exception 'Admins only.'; end if;
  return r;
end $$;

create or replace function public._notify(p_uid uuid, p_title text, p_body text) returns void
language sql security definer set search_path = public as $$
  insert into public.notifications (user_id, title, body) values (p_uid, p_title, p_body);
$$;

-- Admin alerts: in-app inbox + (optional) a phone push through ntfy.sh.
-- To turn the phone push on, see the README ("Phone alerts for admin").
create or replace function public._notify_admins(p_title text, p_body text) returns void
language plpgsql security definer set search_path = public as $$
declare a record; v_topic text;
begin
  for a in select id from public.profiles where role = 'admin' and status = 'active' loop
    insert into public.notifications (user_id, title, body) values (a.id, p_title, p_body);
  end loop;
  select value into v_topic from public.app_settings where key = 'ntfy_topic';
  if v_topic is not null and v_topic <> '' then
    begin
      perform net.http_post(
        url := 'https://ntfy.sh',
        body := jsonb_build_object('topic', v_topic, 'title', p_title, 'message', p_body)
      );
    exception when others then
      null; -- alerts are best effort
    end;
  end if;
end $$;

create or replace function public._make_keyword() returns text
language plpgsql volatile as $$
declare
  words text[] := array['ROSE','LOTUS','PEARL','AMBER','COPPER','JADE','ORCHID','SILK',
                        'DAWN','MANGO','EMBER','IVORY','LILAC','OPAL','SUNRISE','VELVET'];
begin
  return words[1 + floor(random() * array_length(words, 1))::int]
    || '-' || words[1 + floor(random() * array_length(words, 1))::int]
    || '-' || (10 + floor(random() * 90))::int::text;
end $$;

-- ------------------------------------------------------------- triggers

-- Creates the profile when someone signs up. The app sends username, phone, sex
-- and age_confirmed in the sign-up metadata.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  m jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
  u text := lower(coalesce(m->>'username', ''));
  ph text := regexp_replace(coalesce(m->>'phone', ''), '[\s\-()]', '', 'g');
  sx text := m->>'sex';
begin
  if u !~ '^[a-z0-9_]{3,20}$' then raise exception 'Invalid username'; end if;
  if ph !~ '^\+?[0-9]{9,14}$' then raise exception 'Invalid phone number'; end if;
  if sx is null or sx not in ('male', 'female') then raise exception 'Choose male or female'; end if;
  if coalesce(m->>'age_confirmed', '') <> 'true' then raise exception 'You must confirm you are 18 or older'; end if;
  if lower(coalesce(new.email, '')) <> u || '@mverechena.app' then raise exception 'Username does not match'; end if;
  insert into public.profiles (id, username, phone, sex) values (new.id, u, ph, sx);
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.posts_before_insert() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  select username into new.owner_name from public.profiles where id = new.owner_id;
  return new;
end $$;

drop trigger if exists posts_set_owner_name on public.posts;
create trigger posts_set_owner_name
  before insert on public.posts
  for each row execute function public.posts_before_insert();

create or replace function public.likes_counter() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    update public.posts set like_count = like_count + 1 where id = new.post_id;
  elsif tg_op = 'DELETE' then
    update public.posts set like_count = greatest(like_count - 1, 0) where id = old.post_id;
  end if;
  return null;
end $$;

drop trigger if exists post_likes_count on public.post_likes;
create trigger post_likes_count
  after insert or delete on public.post_likes
  for each row execute function public.likes_counter();

-- ------------------------------------------------ callable functions (RPC)

create or replace function public.username_available(p_username text) returns boolean
language sql stable security definer set search_path = public as $$
  select not exists (select 1 from public.profiles where username = lower(trim(p_username)));
$$;

create or replace function public.submit_activation(p_txn text) returns void
language plpgsql security definer set search_path = public as $$
declare r public.profiles; v_txn text := left(trim(coalesce(p_txn, '')), 40);
begin
  if auth.uid() is null then raise exception 'Please sign in.'; end if;
  select * into r from public.profiles where id = auth.uid();
  if not found then raise exception 'Account not found.'; end if;
  if r.status <> 'pending' then raise exception 'Account is already active.'; end if;
  if length(v_txn) < 4 then raise exception 'Enter the Ecocash transaction ID.'; end if;
  update public.profiles
     set activation_txn = v_txn, activation_rejected = null, activation_submitted_at = now()
   where id = r.id;
  perform public._notify_admins('Activation payment to check',
    format('@%s (%s) paid $1. Txn %s. Reference %s.', r.username, r.phone, v_txn, upper(r.username)));
end $$;

create or replace function public.admin_activate_user(p_uid uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._admin();
  update public.profiles set status = 'active' where id = p_uid and status = 'pending';
  if not found then raise exception 'Account not found or already active.'; end if;
  perform public._notify(p_uid, 'Welcome to Mverechena', 'Your account is active. Enjoy!');
end $$;

create or replace function public.admin_reject_activation(p_uid uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._admin();
  update public.profiles set activation_txn = null, activation_rejected = true where id = p_uid;
  perform public._notify(p_uid, 'Payment not found',
    'We could not match your $1 payment. Please check the transaction ID.');
end $$;

create or replace function public.place_bid(p_post_id uuid, p_type text, p_amount numeric)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_me public.profiles; v_post public.posts; v_fem public.profiles;
  v_amt numeric(10,2); v_min numeric; v_status text; v_fee numeric(10,2); v_id uuid;
begin
  v_me := public._me();
  if v_me.sex <> 'male' then raise exception 'Only men can place bids.'; end if;
  if p_type is null or p_type not in ('short', 'full') then
    raise exception 'Choose short or full time.';
  end if;
  v_amt := round(coalesce(p_amount, 0), 2);
  if v_amt < 2 or v_amt > 5000 then raise exception 'Minimum bid is $2.00.'; end if;

  select * into v_post from public.posts where id = p_post_id and approved;
  if not found then raise exception 'That post is not available.'; end if;
  select * into v_fem from public.profiles where id = v_post.owner_id;
  if not found or v_fem.status <> 'active' then
    raise exception 'She is not available right now.';
  end if;

  if exists (select 1 from public.bids
              where male_id = v_me.id and female_id = v_fem.id and type = p_type
                and status in ('pending', 'accepted', 'escrow_submitted', 'escrow_confirmed', 'details_shared')) then
    raise exception 'You already have an open bid with her for that. Cancel it first.';
  end if;

  v_min := case when p_type = 'short' then v_fem.short_min else v_fem.full_min end;
  v_status := case when v_min is not null and v_amt < v_min then 'auto_rejected' else 'pending' end;
  v_fee := public._fee_for(v_amt);

  insert into public.bids (post_id, female_id, female_name, male_id, male_name,
                           type, amount, fee, payout, status)
  values (v_post.id, v_fem.id, v_fem.username, v_me.id, v_me.username,
          p_type, v_amt, v_fee, v_amt - v_fee, v_status)
  returning id into v_id;

  insert into public.bid_admin (bid_id, male_phone, female_phone)
  values (v_id, v_me.phone, v_fem.phone);

  update public.posts set bid_count = bid_count + 1 where id = v_post.id;

  if v_status = 'pending' then
    perform public._notify(v_fem.id, 'New bid for you',
      format('A %s bid of %s is waiting.',
             case when p_type = 'short' then 'short time' else 'full time' end,
             public._money(v_amt)));
  end if;
  return jsonb_build_object('status', v_status, 'bid_id', v_id);
end $$;

create or replace function public.respond_bid(p_bid_id uuid, p_accept boolean) returns void
language plpgsql security definer set search_path = public as $$
declare v_me public.profiles; b public.bids;
begin
  v_me := public._me();
  select * into b from public.bids where id = p_bid_id for update;
  if not found then raise exception 'Bid not found.'; end if;
  if b.female_id <> v_me.id then raise exception 'Not your bid.'; end if;
  if b.status <> 'pending' then raise exception 'This bid is no longer pending.'; end if;
  if p_accept then
    update public.bids
       set status = 'accepted', accepted_at = now(),
           escrow_deadline = now() + interval '24 hours'
     where id = b.id;
    perform public._notify(b.male_id, 'She accepted!',
      format('@%s accepted your %s bid. Pay into escrow within 24h to lock the date.',
             v_me.username, public._money(b.amount)));
  else
    update public.bids set status = 'rejected' where id = b.id;
    perform public._notify(b.male_id, 'Bid declined',
      format('@%s declined your bid.', v_me.username));
  end if;
end $$;

create or replace function public.cancel_bid(p_bid_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare v_me public.profiles; b public.bids;
begin
  v_me := public._me();
  select * into b from public.bids where id = p_bid_id for update;
  if not found then raise exception 'Bid not found.'; end if;
  if b.male_id <> v_me.id then raise exception 'Not your bid.'; end if;
  if b.status not in ('pending', 'accepted') then
    raise exception 'This bid can no longer be cancelled here. Use "Report a problem" if something is wrong.';
  end if;
  update public.bids set status = 'cancelled' where id = b.id;
  if b.status = 'accepted' then
    perform public._notify(b.female_id, 'Bid cancelled',
      format('@%s cancelled the accepted bid.', v_me.username));
  end if;
end $$;

create or replace function public.submit_escrow_txn(p_bid_id uuid, p_txn text) returns void
language plpgsql security definer set search_path = public as $$
declare v_me public.profiles; b public.bids; v_txn text := left(trim(coalesce(p_txn, '')), 40);
begin
  v_me := public._me();
  select * into b from public.bids where id = p_bid_id for update;
  if not found then raise exception 'Bid not found.'; end if;
  if b.male_id <> v_me.id then raise exception 'Not your bid.'; end if;
  if b.status <> 'accepted' then raise exception 'This bid is not waiting for payment.'; end if;
  if length(v_txn) < 4 then raise exception 'Enter the Ecocash transaction ID.'; end if;
  update public.bids
     set status = 'escrow_submitted', escrow_txn = v_txn, escrow_rejected = null,
         escrow_submitted_at = now()
   where id = b.id;
  perform public._notify_admins('Escrow payment to confirm',
    format('@%s paid %s. Ref %s, txn %s.', v_me.username, public._money(b.amount),
           public._code(b.id), v_txn));
end $$;

create or replace function public.admin_confirm_escrow(p_bid_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare b public.bids;
begin
  perform public._admin();
  select * into b from public.bids where id = p_bid_id for update;
  if not found then raise exception 'Bid not found.'; end if;
  if b.status <> 'escrow_submitted' then raise exception 'Nothing to confirm on this bid.'; end if;
  update public.bids set status = 'escrow_confirmed', escrow_confirmed_at = now() where id = b.id;
  insert into public.bid_private (bid_id, female_id, keyword)
  values (b.id, b.female_id, public._make_keyword())
  on conflict (bid_id) do nothing;
  perform public._notify(b.female_id, 'Confirmed - funds in escrow',
    'His payment is safe in escrow. Send the time, place and your phone number to get your keyword.');
  perform public._notify(b.male_id, 'Escrow confirmed',
    'Your funds are safe. You will get her time, place and phone number shortly.');
end $$;

create or replace function public.admin_reject_escrow(p_bid_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare b public.bids;
begin
  perform public._admin();
  select * into b from public.bids where id = p_bid_id for update;
  if not found then raise exception 'Bid not found.'; end if;
  if b.status <> 'escrow_submitted' then raise exception 'Nothing to reject on this bid.'; end if;
  update public.bids set status = 'accepted', escrow_txn = null, escrow_rejected = true where id = b.id;
  perform public._notify(b.male_id, 'Payment not found',
    format('We could not find your payment for %s. Check the transaction ID and try again.',
           public._code(b.id)));
end $$;

create or replace function public.submit_details(
  p_bid_id uuid, p_date_time timestamptz, p_location text, p_phone text) returns void
language plpgsql security definer set search_path = public as $$
declare
  v_me public.profiles; b public.bids;
  v_loc text := left(trim(coalesce(p_location, '')), 200);
  v_phone text := left(trim(coalesce(p_phone, '')), 20);
begin
  v_me := public._me();
  select * into b from public.bids where id = p_bid_id for update;
  if not found then raise exception 'Bid not found.'; end if;
  if b.female_id <> v_me.id then raise exception 'Not your bid.'; end if;
  if b.status <> 'escrow_confirmed' then raise exception 'Escrow is not confirmed yet.'; end if;
  if p_date_time is null or p_date_time <= now() then raise exception 'Pick a time in the future.'; end if;
  if length(v_loc) < 3 then raise exception 'Enter a meeting place.'; end if;
  if length(v_phone) < 7 then raise exception 'Enter your phone number.'; end if;
  insert into public.bid_details (bid_id, date_time, location, phone)
  values (b.id, p_date_time, v_loc, v_phone)
  on conflict (bid_id) do update
    set date_time = excluded.date_time, location = excluded.location, phone = excluded.phone;
  update public.bids set status = 'details_shared', details_at = now() where id = b.id;
  perform public._notify(b.male_id, 'Your date details are ready',
    format('@%s sent the time, place and phone number. Open My bids to see them.', v_me.username));
end $$;

create or replace function public.submit_keyword(p_bid_id uuid, p_keyword text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_me public.profiles; b public.bids; v_kw text;
begin
  v_me := public._me();
  select * into b from public.bids where id = p_bid_id for update;
  if not found then raise exception 'Bid not found.'; end if;
  if b.male_id <> v_me.id then raise exception 'Not your bid.'; end if;
  if b.status <> 'details_shared' then raise exception 'This date is not ready for a keyword.'; end if;
  if b.keyword_attempts >= 5 then
    raise exception 'Too many wrong attempts. Please contact Mverechena support.';
  end if;
  select keyword into v_kw from public.bid_private where bid_id = b.id;
  if v_kw is null then raise exception 'Keyword missing. Contact support.'; end if;

  if regexp_replace(upper(coalesce(p_keyword, '')), '[^A-Z0-9]', '', 'g')
       = regexp_replace(upper(v_kw), '[^A-Z0-9]', '', 'g') then
    update public.bids set status = 'completed', completed_at = now() where id = b.id;
    perform public._notify_admins('Keyword received - pay her',
      format('@%s entered the keyword for %s. Pay @%s %s (fee %s).',
             b.male_name, public._code(b.id), b.female_name,
             public._money(b.payout), public._money(b.fee)));
    perform public._notify(b.female_id, 'Keyword received',
      format('Your payout of %s is being sent to your Ecocash.', public._money(b.payout)));
    return jsonb_build_object('ok', true);
  end if;

  update public.bids set keyword_attempts = keyword_attempts + 1 where id = b.id;
  return jsonb_build_object('ok', false, 'attemptsLeft', 5 - b.keyword_attempts - 1);
end $$;

create or replace function public.admin_mark_paid(p_bid_id uuid, p_payout_txn text) returns void
language plpgsql security definer set search_path = public as $$
declare b public.bids;
begin
  perform public._admin();
  select * into b from public.bids where id = p_bid_id for update;
  if not found then raise exception 'Bid not found.'; end if;
  if b.status <> 'completed' then raise exception 'This bid is not waiting for payout.'; end if;
  update public.bids
     set status = 'paid', payout_txn = left(coalesce(p_payout_txn, ''), 40), paid_at = now()
   where id = b.id;
  perform public._notify(b.female_id, 'You have been paid',
    format('%s was sent to your Ecocash for %s.', public._money(b.payout), public._code(b.id)));
end $$;

create or replace function public.report_problem(p_bid_id uuid, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
declare v_me public.profiles; b public.bids; v_reason text := left(trim(coalesce(p_reason, '')), 500);
begin
  v_me := public._me();
  select * into b from public.bids where id = p_bid_id for update;
  if not found then raise exception 'Bid not found.'; end if;
  if v_me.id not in (b.male_id, b.female_id) then raise exception 'Not your bid.'; end if;
  if b.status not in ('escrow_confirmed', 'details_shared', 'completed') then
    raise exception 'A problem can only be reported once funds are in escrow.';
  end if;
  if length(v_reason) < 3 then raise exception 'Tell us briefly what happened.'; end if;
  update public.bids set status = 'disputed' where id = b.id;
  insert into public.bid_admin (bid_id, disputed_by, dispute_reason, prev_status, disputed_at)
  values (b.id, '@' || v_me.username, v_reason, b.status, now())
  on conflict (bid_id) do update
    set disputed_by = excluded.disputed_by, dispute_reason = excluded.dispute_reason,
        prev_status = excluded.prev_status, disputed_at = excluded.disputed_at;
  perform public._notify_admins('Dispute reported',
    format('%s: %s', public._code(b.id), v_reason));
end $$;

create or replace function public.admin_resolve_dispute(p_bid_id uuid, p_outcome text) returns void
language plpgsql security definer set search_path = public as $$
declare b public.bids;
begin
  perform public._admin();
  select * into b from public.bids where id = p_bid_id for update;
  if not found then raise exception 'Bid not found.'; end if;
  if b.status <> 'disputed' then raise exception 'This bid is not disputed.'; end if;
  if p_outcome = 'refund' then
    update public.bids set status = 'refunded' where id = b.id;
    perform public._notify(b.male_id, 'Refund approved',
      format('Your %s for %s will be refunded.', public._money(b.amount), public._code(b.id)));
    perform public._notify(b.female_id, 'Dispute resolved',
      format('%s was resolved with a refund to the bidder.', public._code(b.id)));
  else
    update public.bids set status = 'completed', completed_at = now() where id = b.id;
    perform public._notify(b.female_id, 'Dispute resolved',
      format('%s was resolved in your favour. Payout is on its way.', public._code(b.id)));
    perform public._notify(b.male_id, 'Dispute resolved',
      format('%s was resolved. The payment goes to her.', public._code(b.id)));
  end if;
end $$;

-- Approve or remove an upload. (The app deletes the file itself from Storage.)
create or replace function public.admin_moderate_post(p_post_id uuid, p_action text) returns void
language plpgsql security definer set search_path = public as $$
declare p public.posts;
begin
  perform public._admin();
  select * into p from public.posts where id = p_post_id;
  if not found then raise exception 'Post not found.'; end if;
  if p_action = 'approve' then
    update public.posts set approved = true where id = p.id;
    perform public._notify(p.owner_id, 'Your post is live', 'It is now on the touchline.');
  else
    delete from public.posts where id = p.id;
    perform public._notify(p.owner_id, 'Post removed',
      'Your upload did not meet our rules and was removed.');
  end if;
end $$;

-- Expires unpaid accepted bids (24h) and stale pending bids (7 days). Runs hourly.
create or replace function public.expire_stale() returns void
language plpgsql security definer set search_path = public as $$
declare r record;
begin
  for r in select id, male_id, female_id from public.bids
            where status = 'accepted' and escrow_deadline < now() loop
    update public.bids set status = 'expired' where id = r.id;
    perform public._notify(r.male_id, 'Bid expired',
      'You did not pay into escrow in time, so the bid expired.');
    perform public._notify(r.female_id, 'Bid expired', 'He did not pay into escrow in time.');
  end loop;
  update public.bids set status = 'expired'
   where status = 'pending' and created_at < now() - interval '7 days';
end $$;

do $$ begin
  create extension if not exists pg_cron;
  perform cron.schedule('mverechena-expire', '0 * * * *', 'select public.expire_stale()');
exception when others then
  raise notice 'pg_cron not enabled (%). Enable it under Database > Extensions to auto-expire bids.', sqlerrm;
end $$;

do $$ begin
  create extension if not exists pg_net;
exception when others then
  raise notice 'pg_net not enabled (%). Phone alerts for admin will be unavailable.', sqlerrm;
end $$;

-- ---------------------------------------------------- security (RLS)

alter table public.profiles       enable row level security;
alter table public.posts          enable row level security;
alter table public.post_likes     enable row level security;
alter table public.bids           enable row level security;
alter table public.bid_admin      enable row level security;
alter table public.bid_private    enable row level security;
alter table public.bid_details    enable row level security;
alter table public.notifications  enable row level security;
alter table public.reports        enable row level security;
alter table public.app_settings   enable row level security;

-- Start from nothing, then grant only what the app needs.
revoke all on public.profiles, public.posts, public.post_likes, public.bids, public.bid_admin,
  public.bid_private, public.bid_details, public.notifications, public.reports,
  public.app_settings from anon, authenticated;

grant select on public.profiles, public.posts, public.post_likes, public.bids, public.bid_admin,
  public.bid_private, public.bid_details, public.notifications, public.reports
  to authenticated;
grant update (short_min, full_min, bio) on public.profiles to authenticated;
grant insert (owner_id, media_url, storage_path, type, caption) on public.posts to authenticated;
grant insert (post_id, user_id) on public.post_likes to authenticated;
grant delete on public.post_likes to authenticated;
grant update (read) on public.notifications to authenticated;
grant insert (post_id, owner_id, reporter_id, reason) on public.reports to authenticated;

drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin());
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists posts_select on public.posts;
create policy posts_select on public.posts for select to authenticated
  using ((public.is_active() and approved) or owner_id = auth.uid() or public.is_admin());
drop policy if exists posts_insert on public.posts;
create policy posts_insert on public.posts for insert to authenticated
  with check (owner_id = auth.uid() and public.is_active() and public.my_sex() = 'female');

drop policy if exists likes_select on public.post_likes;
create policy likes_select on public.post_likes for select to authenticated
  using (public.is_active());
drop policy if exists likes_insert on public.post_likes;
create policy likes_insert on public.post_likes for insert to authenticated
  with check (user_id = auth.uid() and public.is_active());
drop policy if exists likes_delete on public.post_likes;
create policy likes_delete on public.post_likes for delete to authenticated
  using (user_id = auth.uid());

drop policy if exists bids_select on public.bids;
create policy bids_select on public.bids for select to authenticated
  using (male_id = auth.uid() or female_id = auth.uid() or public.is_admin());

drop policy if exists details_select on public.bid_details;
create policy details_select on public.bid_details for select to authenticated
  using (
    public.is_admin()
    or exists (select 1 from public.bids b
                where b.id = bid_details.bid_id
                  and (b.female_id = auth.uid()
                       or (b.male_id = auth.uid()
                           and b.status in ('details_shared', 'completed', 'paid', 'disputed')))));

drop policy if exists private_select on public.bid_private;
create policy private_select on public.bid_private for select to authenticated
  using (female_id = auth.uid() or public.is_admin());

drop policy if exists admin_select on public.bid_admin;
create policy admin_select on public.bid_admin for select to authenticated
  using (public.is_admin());

drop policy if exists notifications_select on public.notifications;
create policy notifications_select on public.notifications for select to authenticated
  using (user_id = auth.uid());
drop policy if exists notifications_update on public.notifications;
create policy notifications_update on public.notifications for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists reports_insert on public.reports;
create policy reports_insert on public.reports for insert to authenticated
  with check (reporter_id = auth.uid() and public.is_active());
drop policy if exists reports_select on public.reports;
create policy reports_select on public.reports for select to authenticated
  using (public.is_admin());

-- Who may call which function from the app.
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.is_admin(), public.is_active(), public.my_sex() to authenticated;
grant execute on function public.username_available(text) to anon, authenticated;
grant execute on function
  public.submit_activation(text),
  public.admin_activate_user(uuid),
  public.admin_reject_activation(uuid),
  public.place_bid(uuid, text, numeric),
  public.respond_bid(uuid, boolean),
  public.cancel_bid(uuid),
  public.submit_escrow_txn(uuid, text),
  public.admin_confirm_escrow(uuid),
  public.admin_reject_escrow(uuid),
  public.submit_details(uuid, timestamptz, text, text),
  public.submit_keyword(uuid, text),
  public.admin_mark_paid(uuid, text),
  public.report_problem(uuid, text),
  public.admin_resolve_dispute(uuid, text),
  public.admin_moderate_post(uuid, text)
  to authenticated;

-- ------------------------------------------------------------ storage

-- Public bucket: photos/videos get a plain link the app can show. 50MB per file.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('posts', 'posts', true, 52428800, array['image/*', 'video/*'])
on conflict (id) do update
  set public = true, file_size_limit = 52428800, allowed_mime_types = array['image/*', 'video/*'];

drop policy if exists posts_upload on storage.objects;
create policy posts_upload on storage.objects for insert to authenticated
  with check (bucket_id = 'posts'
              and (storage.foldername(name))[1] = auth.uid()::text
              and public.is_active());

drop policy if exists posts_remove on storage.objects;
create policy posts_remove on storage.objects for delete to authenticated
  using (bucket_id = 'posts'
         and (public.is_admin() or (storage.foldername(name))[1] = auth.uid()::text));

-- ----------------------------------------------------------- realtime

do $$
declare t text;
begin
  foreach t in array array['profiles', 'posts', 'bids', 'bid_details', 'bid_private',
                           'bid_admin', 'notifications'] loop
    begin
      execute format('alter publication supabase_realtime add table public.%I', t);
    exception when duplicate_object then
      null;
    end;
  end loop;
end $$;
